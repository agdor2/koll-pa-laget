#!/usr/bin/env python3
"""Fetch a compact SMHI forecast snapshot for Vallentuna.

This script stores only the current temperature and a short weather summary.
It deliberately does not fetch warning data; warning feeds should be added only
once their endpoint and usage conditions have been verified.
"""
import json
import os
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

LAT = 59.534
LON = 18.077
URL = (
    "https://opendata-download-metfcst.smhi.se/api/category/pmp3g/"
    f"version/2/geotype/point/lon/{LON}/lat/{LAT}/data.json"
)
OUT = Path("data/smhi.json")


def main():
    req = urllib.request.Request(URL, headers={"User-Agent": "KollPaLagetPrototype/0.1 (open-data client)"})
    with urllib.request.urlopen(req, timeout=20) as response:
        payload = json.load(response)
    times = payload.get("timeSeries", [])
    if not times:
        raise RuntimeError("SMHI-svaret innehöll ingen prognosserie")
    first = times[0]
    values = {item.get("name"): item.get("values", [None])[0] for item in first.get("parameters", [])}
    temperature = values.get("t")
    if temperature is None:
        raise RuntimeError("Kunde inte hitta temperatur i SMHI-svaret")
    symbol = values.get("Wsymb2")
    labels = {
        1: "Klart", 2: "Nästan klart", 3: "Växlande molnighet", 4: "Halvklart",
        5: "Molnigt", 6: "Mulet", 7: "Dimma", 8: "Lätt regnskur",
        9: "Regnskur", 10: "Kraftig regnskur", 11: "Åskskur", 12: "Lätt snöblandat regn",
        13: "Snöblandat regn", 14: "Kraftigt snöblandat regn", 15: "Lätt snöby",
        16: "Snöby", 17: "Kraftig snöby", 18: "Lätt regn", 19: "Regn",
        20: "Kraftigt regn", 21: "Åska", 22: "Lätt snöblandat regn", 23: "Snöblandat regn",
        24: "Kraftigt snöblandat regn", 25: "Lätt snöfall", 26: "Snöfall", 27: "Kraftigt snöfall"
    }
    data = {
        "status": "live",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "forecast_for": first.get("validTime"),
        "temperature_c": round(float(temperature), 1),
        "summary": labels.get(int(symbol), "Väderprognos från SMHI") if symbol is not None else "Väderprognos från SMHI",
        "source": "SMHI öppna data",
        "source_url": "https://www.smhi.se/data/om-smhis-data/villkor-for-anvandning",
        "location": "Vallentuna",
        "note": "Prognos, inte en varning. Kontrollera alltid SMHI:s officiella varningssida."
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    old_text = OUT.read_text(encoding="utf-8") if OUT.exists() else ""
    old_data = {}
    if old_text:
        try:
            old_data = json.loads(old_text)
        except json.JSONDecodeError:
            old_data = {}

    # Do not change the saved file on every scheduled run. A new commit is only
    # needed when the displayed conditions or the forecast time actually changes.
    display_fields = ("temperature_c", "summary", "forecast_for")
    if old_data.get("status") == "live" and all(old_data.get(k) == data.get(k) for k in display_fields):
        print("Vädervärdena är oförändrade; ingen filändring eller commit behövs")
        return

    new_text = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    OUT.write_text(new_text, encoding="utf-8")
    print("SMHI-data uppdaterad")

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"Fel vid SMHI-hämtning: {exc}", file=sys.stderr)
        sys.exit(1)
