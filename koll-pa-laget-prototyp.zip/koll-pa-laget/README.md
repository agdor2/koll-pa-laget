# Koll på läget – prototyp

En liten, statisk svensk beredskapswebbplats. Ingen databas, ingen betald tjänst och inga externa JavaScript-bibliotek.

## Innehåll
- `index.html`: mobilvänlig webbplats och checklista som sparas lokalt i webbläsaren.
- `data/smhi.json`: liten kompakt datafil som webbplatsen läser.
- `scripts/update_smhi.py`: hämtar en kort temperatur-/vädersammanfattning från SMHI:s prognos-API för Vallentuna.
- `.github/workflows/update-smhi.yml`: GitHub Actions-workflow som kör en gång i timmen och bara committar om datafilen ändrats.

## Viktigt
- Den medföljande `data/smhi.json` är exempeldata. Webbplatsen visar detta tydligt tills GitHub Actions har ersatt den med riktiga data.
- Prototypen visar inte automatiska myndighetsvarningar. Den länkar till SMHI:s officiella varningssida i stället.
- Innan publicering: kontrollera aktuell SMHI-dokumentation och licensvillkor, samt testa workflow manuellt i GitHub Actions.
- GitHub Pages passar för utveckling/test, men GitHubs villkor begränsar användning av Pages som gratis hosting för webbplatser som huvudsakligen driver kommersiell verksamhet. Innan monetisering behöver vi välja hosting vars villkor tillåter det.

## Starta på GitHub
1. Skapa ett nytt offentligt repo som heter `koll-pa-laget`.
2. Ladda upp samtliga filer och mappar från denna mapp till repo-roten.
3. Gå till **Settings → Pages** och välj publicering från `main` / root.
4. Gå till **Actions** och kör `Uppdatera SMHI-data` manuellt första gången.
5. Kontrollera att `data/smhi.json` visar `"status": "live"`.

Workflowen behöver standardbehörighet att skriva till repo (`contents: write`). Om push nekas, kontrollera **Settings → Actions → General → Workflow permissions** och välj read and write permissions.
